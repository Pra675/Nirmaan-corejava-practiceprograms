
import java.util.Scanner;

public class PositiveNegative {
    
    public static void main(String[]args){
    Scanner sc= new Scanner(System.in);
    int num =sc.nextln();
    if(num>0){
        System.out.println("positive Number");
    }
    else if(num<0){
        System.out.println("negative number");
    }
    else{
        System.out.println("Zero");
        
    }
  }
}
